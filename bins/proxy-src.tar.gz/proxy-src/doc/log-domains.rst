log domains
-----------

right now we support these log-domains:

* default
* lua

