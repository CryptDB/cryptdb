#ifndef __SQL_TOKENIZER_KEYWORDS_H__
#define __SQL_TOKENIZER_KEYWORDS_H__

int *sql_keywords_get(void);
int sql_keywords_get_count(void);

#endif
